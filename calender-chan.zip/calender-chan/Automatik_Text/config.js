module.exports = {
    token: "ODk3ODc4NjQyMzU1NDk5MDA5.YWcEpg.roS_v2sCq7XZbzRuel5-MHYQyfA",
    file_location: "./file/",
    file_name: "hi.txt",
    guild_id: "755050175554125844",
    channel_id: "898478135794868274",
    prefix: "$"
}